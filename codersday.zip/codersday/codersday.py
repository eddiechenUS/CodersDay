import serial  # 引用pySerial模組
import os
from subprocess import call

COM_PORT = '/dev/ttyUSB0'    # 指定通訊埠名稱
BAUD_RATES = 9600    # 設定傳輸速率
ser = serial.Serial(COM_PORT, BAUD_RATES)   # 初始化序列通訊埠


def executeCommand(cmd):
    print("Command: ", cmd)
    os.system(cmd)


def volumeControl(data):
    try:
        volume = (data * -0.5 ) + 125
        if (volume >= 0) and (volume <= 100):
            executeCommand('amixer sset Master ' + str(volume) + '%')
    except:
        print('cannot set volume')



def gestureControl(data):
    print(data)
    if data == "DOWN":
        executeCommand('dbus-send --type=method_call --dest=org.gnome.ScreenSaver /org/gnome/ScreenSaver org.gnome.ScreenSaver.Lock')
    if data == "UP":
        executeCommand('dbus-send --session --type=method_call --dest=org.gnome.Shell /org/gnome/Shell org.gnome.Shell.Eval string:\'Main.overview.show();\'')
    if data == "LEFT":
        executeCommand('google-chrome -app=https://poczta.tt.com.pl/owa/#path=/mail')
    if data == "RIGHT":
        executeCommand('teams')
    
            

def main():
    try:
        while True:
            while ser.in_waiting:          # 若收到序列資料…
                data_raw = ser.readline()  # 讀取一行
                data = data_raw.decode().rstrip()   # 用預設的UTF-8解碼
                
                try:
                    volumeControl(int(data))
                except:
                    gestureControl(data)


                

    except KeyboardInterrupt:
        ser.close()
        print('Bye!')

if __name__ == "__main__":
    main()